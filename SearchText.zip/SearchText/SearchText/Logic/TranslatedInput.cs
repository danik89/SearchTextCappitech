﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchText.Logic
{
    public class TranslatedInput
    {
        public bool IsReversed { get; set; }
        public bool IsInsensetive { get; set; }
        public string Word { get; set; }
        public List<Source> Sources { get; set; }
    }

}
