﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchText.Logic
{
    public class InputTranslate
    {
        private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public TranslatedInput TranslateInput(string[] input)
        {
            log.Debug("Translating Input");
            TranslatedInput translated = new TranslatedInput();
            translated.IsInsensetive = translated.IsReversed = false;
            foreach (var inputString in input)
            {
                if (inputString.Equals("-i"))
                    translated.IsInsensetive = true;
                else if (inputString.Equals("-v"))
                    translated.IsReversed = true;
                else if (inputString.Contains("file:") || inputString.Contains("url:"))
                    translated.Sources = getSources(inputString);
                else if (!inputString.Contains("grep"))
                    translated.Word = inputString;
            }
            log.Debug(String.Format("Translating result: CaseSensitive = {0}, Reversed = {1}, Word = {2}, There are {3} source to search in", translated.IsInsensetive.ToString(), translated.IsReversed.ToString(),
                translated.Word, translated.Sources.Count()));

            return translated;
        }

        private List<Source> getSources(string inputString)
        {
            log.Debug("Getting sources");
            List<Source> sources = new List<Source>();
            string[] splitted = inputString.Split(',');
            if (splitted != null && splitted.Length > 0)
            {
                foreach(var file in splitted)
                {
                    Source source = new Source();
                    var index = file.IndexOf("file:");
                    if (index >= 0)
                    {
                        source.IsFile = true;
                        source.Path = file.Substring(index + 5);
                        log.Debug(String.Format("File source found, path is: {0}", source.Path));
                    }
                    else
                    {
                        source.IsFile = false;
                        var urlIndex = file.IndexOf("url:");
                        if (urlIndex >= 0)
                        {
                            source.Path = file.Substring(urlIndex + 4);
                            log.Debug(String.Format("URL source found, path is: {0}", source.Path));
                        }
                    }
                    sources.Add(source);
                }
            }
            return sources;
        }
    }
}
