﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchText.Logic
{
    public class Source
    {
        public bool IsFile { get; set; }
        public string Path { get; set; }
    }
}
